Moved from [code.google.com/archive/p/phpquery](https://code.google.com/archive/p/phpquery/)

# phpQuery - pq();

phpQuery is a server-side, chainable, CSS3 selector driven Document Object Model (DOM) API based on jQuery JavaScript Library.

Library is written in PHP5 and provides additional Command Line Interface (CLI).
